Caldera Bank SIEM - TIBER/DORA Purple Team Framework
=====================================================

Automated SIEM use case validation for banking institutions using
MITRE Caldera adversary emulation.

Features:
- 15 pre-built SIEM correlation rules (Splunk Saved Searches)
- 63 MITRE ATT&CK techniques mapped to banking threats
- 6 adversary profiles: Ransomware, APT Espionage, Insider Threat,
  Lateral Movement, Defense Evasion, Data Exfiltration
- Comprehensive Purple Team Dashboard with KPIs, MITRE Heatmap,
  Kill Chain Timeline, and DORA Compliance view
- DORA/TIBER-EU/MaRisk/BAIT regulatory compliance mapping
- Summary-index-based kill chain meta-correlation

Requirements:
- Splunk Enterprise >= 9.0
- MITRE Caldera v5.x (for adversary emulation)
- caldera and siem_summary indexes

Documentation & Source Code:
  https://github.com/icepaule/IceUseCaseTesting
  https://icepaule.github.io/IceUseCaseTesting/

Author: icepaule
License: Apache License 2.0
